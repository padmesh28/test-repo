# NiFi Registry Helm Chart (Minimal, ConfigMap-driven)

This chart is intentionally minimal and avoids startup scripts.

## Included resources
- Deployment
- Service
- Optional Ingress (cert-manager ClusterIssuer support)
- Optional PersistentVolumeClaim
- ConfigMap for:
  - `identity-providers.xml`
  - `authorizers.xml`
  - `nifi-registry.properties`

## Install
```bash
helm upgrade --install nifi-registry ./nifi-registry-chart -n nifi --create-namespace
```

## Your use case example
```yaml
image:
  repository: apache/nifi-registry
  tag: "2.6.0"

ingress:
  enabled: true
  className: nginx
  host: registry.example.com
  clusterIssuer: letsencrypt-prod
  tls:
    enabled: true
    secretName: nifi-registry-tls

gitToken:
  enabled: true
  existingSecret: nifi-git-token
  key: token
  envName: GIT_TOKEN

persistence:
  enabled: true
  size: 10Gi

configFiles:
  identityProvidersXml: |
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <identityProviders>
      <!-- your LDAP identity provider config -->
    </identityProviders>

  authorizersXml: |
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <authorizers>
      <!-- your LDAP authorizer config -->
    </authorizers>

  nifiRegistryProperties: |
    nifi.registry.web.http.host=0.0.0.0
    nifi.registry.web.http.port=18080
    nifi.registry.flow.storage.directory=./flow_storage
    nifi.registry.db.directory=./database
    # add your LDAP/provider settings here
```

Apply this with:
```bash
helm upgrade --install nifi-registry ./nifi-registry-chart -n nifi --create-namespace -f my-values.yaml
```

## Required secrets (when enabled)
- `gitToken.existingSecret`: exported as env var (default `GIT_TOKEN`)

If `gitToken.enabled=true`, `gitToken.existingSecret` is required.
